document.addEventListener("DOMContentLoaded", () => {

    // State
    let totalCalories = 0;
    let totalPrice = 0.00;

    // Elements
    const bowlInterior = document.getElementById("bowl-contents");
    const priceEl = document.getElementById("total-price");
    const calEl = document.getElementById("total-kcal");
    const ingredients = document.querySelectorAll(".ingredient-card");

    // Add Click Listeners
    ingredients.forEach(card => {
        card.addEventListener("click", (e) => {
            const name = card.dataset.name;
            const price = parseFloat(card.dataset.price);
            const cal = parseInt(card.dataset.cal);
            const imgSrc = card.dataset.img;

            // Update State
            totalCalories += cal;
            totalPrice += price;
            updateStats();

            // Trigger Animation
            runSlowAddAnimation(imgSrc, card);
        });
    });

    function updateStats() {
        gsap.to(priceEl, {
            innerText: totalPrice.toFixed(2),
            snap: { innerText: 1 }, // Integer snap for INR usually, but 2 dec safe
            duration: 0.5
        });
        gsap.to(calEl, {
            innerText: totalCalories,
            snap: { innerText: 1 },
            duration: 0.5
        });
    }

    function runSlowAddAnimation(imgSrc, sourceEl) {
        // 1. Create a clone (Image)
        const flyer = document.createElement("img");
        flyer.src = imgSrc;
        flyer.className = "flying-ingredient";

        // Large Size for Visibility
        flyer.style.width = "100px";
        flyer.style.height = "100px";
        flyer.style.objectFit = "contain";
        flyer.style.position = "absolute";
        flyer.style.zIndex = "100";
        document.body.appendChild(flyer);

        // Get coordinates
        const startRect = sourceEl.getBoundingClientRect();
        const bowlRect = bowlInterior.getBoundingClientRect();
        const bowlCenterX = bowlRect.left + bowlRect.width / 2;
        const bowlCenterY = bowlRect.top + bowlRect.height / 2;

        // Start from clicked item
        gsap.set(flyer, {
            x: startRect.left,
            y: startRect.top,
            opacity: 1
        });

        const timeline = gsap.timeline({
            onComplete: () => {
                flyer.remove();
                addToBowl(imgSrc);
            }
        });

        // 2. Slow Fly to Center (Arc)
        timeline.to(flyer, {
            x: bowlCenterX - 50, // Center adjust (half width)
            y: bowlCenterY - 50,
            duration: 1.2, // Slower
            ease: "power2.inOut",
            rotation: 720,
            scale: 1.2 // Grow slightly
        })
            // 3. "Cut/Splash" effect
            .to(flyer, {
                scale: 1.5, // Flash larger
                duration: 0.1,
                opacity: 0.8
            })
            .to(flyer, {
                scale: 0.2,
                opacity: 0,
                duration: 0.2
            });
    }

    function addToBowl(imgSrc) {
        // Add permanent item
        const chunk = document.createElement("img");
        chunk.src = imgSrc;
        chunk.className = "bowl-item-added";

        // Randomize placement slightly within bowl
        const randomRot = Math.random() * 360;

        chunk.style.transform = `rotate(${randomRot}deg)`;
        bowlInterior.appendChild(chunk);

        // Pop in
        gsap.from(chunk, {
            scale: 0,
            opacity: 0,
            duration: 0.4,
            ease: "back.out(2)"
        });
    }
});
