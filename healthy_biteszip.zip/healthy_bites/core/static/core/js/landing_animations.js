document.addEventListener("DOMContentLoaded", () => {

    const tl = gsap.timeline();

    const bowl = document.getElementById("bowl-container");
    const fillMask = document.querySelector(".bowl-fill-mask");
    const container = document.getElementById("ingredients-field");
    const textOverlay = document.querySelector(".hero-text-overlay");

    // High-res Image Emojis
    const items = ['🥑', '🍅', '🥒', '🥬', '🌽', '🧅', '🥕', '🥔', '🥦'];
    const scatterElements = [];

    // 1. Setup Ingredients off-stage
    for (let i = 0; i < 30; i++) {
        const el = document.createElement("div");
        el.className = "scatter-item";
        el.innerText = items[i % items.length];
        container.appendChild(el);
        scatterElements.push(el);

        // Random Angle Position off-screen
        const angle = Math.random() * Math.PI * 2;
        const radius = Math.max(window.innerWidth, window.innerHeight) * 0.8;
        const startX = Math.cos(angle) * radius;
        const startY = Math.sin(angle) * radius;

        gsap.set(el, { x: startX, y: startY, opacity: 1, scale: 0.5 + Math.random() });
    }

    // --- ANIMATION SEQUENCE ---

    // 1. Bowl Drops from Top (Slower, heavier impact)
    tl.to(bowl, {
        y: 0,
        duration: 2.0,
        ease: "bounce.out"
    });

    // 2. Ingredients Rush In (Slower, Larger visibility)
    tl.to(scatterElements, {
        x: 0,
        y: 0,
        duration: 3.5, // MUCH SLOWER
        scale: 0.8, // Larger
        opacity: 0, // Fade out at center
        rotation: 360,
        stagger: {
            amount: 1.5,
            from: "random"
        },
        ease: "power1.inOut"
    }, "-=1.0");

    // 3. Shake & Fill
    tl.to(bowl, {
        rotation: 15,
        duration: 0.1,
        yoyo: true,
        repeat: 5,
        ease: "linear"
    }, "-=1.0")

        // 4. Reveal Salad (Fill up)
        .set(fillMask, { opacity: 1 })
        .fromTo(fillMask,
            { clipPath: "circle(0% at 50% 50%)" },
            { clipPath: "circle(100% at 50% 50%)", duration: 1.5, ease: "power2.out" }
            , "<")

        // 5. Spin Bowl (Showcase)
        .to(bowl, {
            rotation: 360,
            duration: 30, // Slower spin
            repeat: -1,
            ease: "linear"
        }, "-=0.5");

    // 6. Reveal Text (IMMEDIATELY and FAST)
    tl.to(textOverlay, {
        opacity: 1,
        scale: 1,
        duration: 0.5, // Fast snap
        ease: "back.out(1.7)"
    }, "<"); // Happened at start of spin

});
