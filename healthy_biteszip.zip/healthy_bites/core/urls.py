from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),
    path('customize/', views.customize, name='customize'),
    path('menu/', views.menu, name='menu'),
    path('diet-plans/', views.diet_plans, name='diet_plans'),
    path('enquiry/', views.enquiry, name='enquiry'),
    path('checkout/', views.checkout, name='checkout'),
    path('tracking/', views.tracking, name='tracking'),
    path('manager/', views.manager, name='manager'),
]
