from django.shortcuts import render

def index(request):
    """Landing page with 'Falling Bowl' animation."""
    return render(request, 'core/index.html')

def customize(request):
    """Interactive bowl builder."""
    # Context could include ingredient prices/calories from DB later
    return render(request, 'core/customize.html')

def menu(request):
    """Food menu customization and meal plans."""
    return render(request, 'core/menu.html')

def diet_plans(request):
    """Diet planning and dietician guides."""
    return render(request, 'core/diet_plans.html')

def enquiry(request):
    """Enquiry form."""
    return render(request, 'core/enquiry.html')

def checkout(request):
    """Order summary and payment."""
    return render(request, 'core/checkout.html')

def tracking(request):
    """Delivery tracking visualization."""
    return render(request, 'core/tracking.html')

def manager(request):
    """Admin dashboard for orders and prices."""
    return render(request, 'core/manager.html')
