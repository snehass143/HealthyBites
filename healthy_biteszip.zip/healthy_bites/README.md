# Healthy Bites 🥗

A modern, interactive healthy food delivery website built with Django and Vanilla JS (GSAP).

## Features
- 🎬 **Cinematic Landing Page**: Falling ingredients & bowl animations.
- 🥑 **Interactive Customization**: Build your bowl with "cutting" effects.
- 📱 **Modern UI**: Glassmorphism design system.

## Setup Instructions

### 1. Install Python
Ensure Python 3.10+ is installed and added to PATH.

### 2. Install Dependencies
```bash
pip install -r requirements.txt
```

### 3. Run Server
```bash
python manage.py runserver
```

Visit `http://127.0.0.1:8000` to view the site.
